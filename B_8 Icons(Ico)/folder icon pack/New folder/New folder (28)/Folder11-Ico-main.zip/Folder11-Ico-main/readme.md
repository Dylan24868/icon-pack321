# Folder11 Ico

Automated repo for [Folder11](https://github.com/icon11-community/Folder11).
